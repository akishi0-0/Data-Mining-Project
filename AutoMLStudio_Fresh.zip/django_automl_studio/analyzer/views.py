import uuid
from pathlib import Path

from django.conf import settings
from django.contrib import messages
from django.http import HttpResponseBadRequest
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .engine import make_prediction, read_dataset, train_and_analyze

MAX_UPLOAD_BYTES = 25 * 1024 * 1024


def home(request):
    context = {'analysis': request.session.get('analysis')}
    return render(request, 'analyzer/index.html', context)


@require_POST
def upload_dataset(request):
    uploaded = request.FILES.get('dataset')
    if not uploaded:
        messages.error(request, 'Choose a CSV or Excel file first.')
        return redirect('home')
    suffix = Path(uploaded.name).suffix.lower()
    if suffix not in {'.csv', '.xlsx', '.xls'}:
        messages.error(request, 'Only .csv, .xlsx and .xls files are supported.')
        return redirect('home')
    if uploaded.size > MAX_UPLOAD_BYTES:
        messages.error(request, 'The file is larger than 25 MB. Please upload a smaller dataset.')
        return redirect('home')
    upload_id = uuid.uuid4().hex
    stored_path = settings.APP_DATA_ROOT / 'uploads' / f'{upload_id}{suffix}'
    with stored_path.open('wb') as destination:
        for chunk in uploaded.chunks():
            destination.write(chunk)
    try:
        df = read_dataset(stored_path)
    except Exception as exc:
        stored_path.unlink(missing_ok=True)
        messages.error(request, f'Could not read that file: {exc}')
        return redirect('home')
    request.session['upload_path'] = str(stored_path)
    request.session['upload_name'] = uploaded.name
    request.session['upload_columns'] = list(df.columns)
    request.session['upload_rows'] = int(len(df))
    request.session.pop('analysis', None)
    messages.success(request, f'{uploaded.name} is ready. Select a target column to continue.')
    return redirect('home')


@require_POST
def analyze_dataset(request):
    path = request.session.get('upload_path')
    target = request.POST.get('target', '')
    task = request.POST.get('task', 'auto')
    if not path or not Path(path).exists():
        messages.error(request, 'Upload a dataset before running analysis.')
        return redirect('home')
    if task not in {'auto', 'classification', 'regression'}:
        task = 'auto'
    try:
        df = read_dataset(Path(path))
        result = train_and_analyze(df, target, task, settings.APP_DATA_ROOT / 'models')
        request.session['analysis'] = result
        request.session.modified = True
        messages.success(request, 'Data preparation and model training are complete.')
    except Exception as exc:
        messages.error(request, f'Analysis could not be completed: {exc}')
    return redirect('home')


@require_POST
def predict(request):
    analysis = request.session.get('analysis')
    if not analysis:
        messages.error(request, 'Run an analysis before requesting a prediction.')
        return redirect('home')
    values = {field['name']: request.POST.get(f'feature_{i}', '') for i, field in enumerate(analysis.get('input_fields', []))}
    try:
        answer = make_prediction(settings.APP_DATA_ROOT / 'models', analysis['model_id'], values)
        analysis['last_prediction'] = answer
        request.session['analysis'] = analysis
        request.session.modified = True
        messages.success(request, 'Prediction generated.')
    except Exception as exc:
        messages.error(request, f'Prediction failed: {exc}')
    return redirect('home')


@require_POST
def reset(request):
    request.session.pop('analysis', None)
    request.session.pop('upload_path', None)
    request.session.pop('upload_name', None)
    request.session.pop('upload_columns', None)
    request.session.pop('upload_rows', None)
    return redirect('home')

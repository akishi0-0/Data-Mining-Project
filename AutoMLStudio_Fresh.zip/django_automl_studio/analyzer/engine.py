"""Dataset cleaning, EDA, AutoML training and prediction helpers."""
from __future__ import annotations

import base64
import io
import json
import re
import uuid
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from joblib import dump, load
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix, f1_score,
    mean_absolute_error, mean_squared_error, precision_score, r2_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

sns.set_theme(style='whitegrid', context='notebook')


def read_dataset(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix == '.csv':
        try:
            df = pd.read_csv(path, low_memory=False)
        except UnicodeDecodeError:
            df = pd.read_csv(path, encoding='latin-1', low_memory=False)
    elif suffix in ('.xlsx', '.xls'):
        df = pd.read_excel(path)
    else:
        raise ValueError('Please upload a CSV or Excel (.xlsx/.xls) file.')
    if df.empty:
        raise ValueError('The uploaded dataset is empty.')
    # Make column labels safe and unique, including numeric Excel headers.
    labels = []
    seen = {}
    for i, col in enumerate(df.columns):
        label = str(col).strip() or f'column_{i + 1}'
        count = seen.get(label, 0)
        seen[label] = count + 1
        labels.append(label if count == 0 else f'{label}_{count + 1}')
    df.columns = labels
    return df


def _is_identifier_column(name: str, series: pd.Series) -> bool:
    key = re.sub(r'[^a-z0-9]+', '', name.lower())
    n = max(len(series), 1)
    unique_ratio = series.nunique(dropna=True) / n
    id_name = key in {'id', 'index', 'uuid', 'passengerid', 'customerid', 'userid', 'recordid', 'transactionid', 'orderid', 'employeeid', 'studentid', 'productid', 'patientid'}
    # Drop identifier-like fields and high-cardinality text columns, not ordinary numbers.
    high_card_text = (not pd.api.types.is_numeric_dtype(series)) and series.nunique(dropna=True) > 60 and unique_ratio > 0.35
    return (id_name and unique_ratio > 0.5) or high_card_text


class IQRCapper(BaseEstimator, TransformerMixin):
    """Fit IQR clipping bounds on training rows only, avoiding test-data leakage."""
    def fit(self, X, y=None):
        array = np.asarray(X, dtype=float)
        q1 = np.nanpercentile(array, 25, axis=0)
        q3 = np.nanpercentile(array, 75, axis=0)
        spread = q3 - q1
        lower = q1 - 1.5 * spread
        upper = q3 + 1.5 * spread
        flat = (~np.isfinite(spread)) | (spread <= 0)
        self.lower_ = np.where(flat, -np.inf, lower)
        self.upper_ = np.where(flat, np.inf, upper)
        return self

    def transform(self, X):
        array = np.asarray(X, dtype=float)
        return np.clip(array, self.lower_, self.upper_)


def _cap_outliers(df: pd.DataFrame, columns: list[str]) -> tuple[pd.DataFrame, dict[str, int]]:
    out = df.copy()
    counts: dict[str, int] = {}
    for col in columns:
        values = pd.to_numeric(out[col], errors='coerce')
        q1, q3 = values.quantile([0.25, 0.75])
        iqr = q3 - q1
        if pd.isna(iqr) or iqr <= 0:
            counts[col] = 0
            continue
        lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        mask = values.notna() & ((values < lower) | (values > upper))
        counts[col] = int(mask.sum())
        out[col] = values.clip(lower=lower, upper=upper)
    return out, counts


def _fig_to_base64(fig) -> str:
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png', dpi=115, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode('ascii')


def _make_eda_plots(df: pd.DataFrame, target: str, numeric_cols: list[str]) -> list[dict]:
    plots = []
    # Target distribution
    fig, ax = plt.subplots(figsize=(7.2, 3.5))
    if pd.api.types.is_numeric_dtype(df[target]) and df[target].nunique() > 18:
        sns.histplot(df[target].dropna(), kde=True, ax=ax, color='#4361ee')
    else:
        order = df[target].astype(str).value_counts().index[:15]
        sns.countplot(data=df.assign(_target=df[target].astype(str)), y='_target', order=order, ax=ax, color='#4361ee')
    ax.set_title(f'Target distribution · {target}', loc='left', fontweight='bold')
    ax.set_xlabel('Count / value'); ax.set_ylabel('')
    plots.append({'title': 'Target distribution', 'subtitle': 'How the selected target is distributed', 'image': _fig_to_base64(fig)})

    candidates = [c for c in numeric_cols if c != target][:3]
    if candidates:
        plot_data = df[candidates].melt(var_name='Feature', value_name='Value')
        fig, ax = plt.subplots(figsize=(7.2, 3.5))
        sns.boxplot(data=plot_data, x='Feature', y='Value', ax=ax, color='#b9c7ff')
        ax.set_title('Numeric feature box plots', loc='left', fontweight='bold')
        ax.tick_params(axis='x', rotation=15)
        plots.append({'title': 'Outlier overview', 'subtitle': 'Box plots after IQR capping', 'image': _fig_to_base64(fig)})

        fig, axes = plt.subplots(1, len(candidates), figsize=(7.2, 3.3), squeeze=False)
        for ax, col in zip(axes[0], candidates):
            sns.histplot(df[col].dropna(), kde=True, ax=ax, color='#0f9d8a')
            ax.set_title(col); ax.set_xlabel('')
        fig.suptitle('Feature distributions', x=0.03, ha='left', fontweight='bold')
        plots.append({'title': 'Feature distributions', 'subtitle': 'Numeric columns and their spread', 'image': _fig_to_base64(fig)})

    if len(candidates) >= 2:
        fig, ax = plt.subplots(figsize=(7.2, 3.5))
        sample = df[candidates[:2] + [target]].dropna().sample(min(700, len(df[candidates[:2] + [target]].dropna())), random_state=42) if len(df) else df
        if sample.empty:
            plt.close(fig)
        else:
            hue = target if sample[target].nunique() <= 10 else None
            sns.scatterplot(data=sample, x=candidates[0], y=candidates[1], hue=hue, alpha=0.7, ax=ax, palette='viridis' if hue else None)
            ax.set_title(f'{candidates[0]} vs {candidates[1]}', loc='left', fontweight='bold')
            plots.append({'title': 'Feature relationship', 'subtitle': 'Scatter plot for the first two numeric features', 'image': _fig_to_base64(fig)})

    corr_cols = numeric_cols[:12]
    if len(corr_cols) >= 2:
        fig, ax = plt.subplots(figsize=(7.2, 4.2))
        corr = df[corr_cols].corr(numeric_only=True)
        sns.heatmap(corr, cmap='vlag', center=0, annot=len(corr_cols) <= 8, fmt='.2f', ax=ax, linewidths=.4)
        ax.set_title('Correlation heatmap', loc='left', fontweight='bold')
        plots.append({'title': 'Correlation heatmap', 'subtitle': 'Pairwise relationships between numeric features', 'image': _fig_to_base64(fig)})
    return plots


def _json_safe(value):
    if pd.isna(value):
        return ''
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    return str(value)


def train_and_analyze(df_raw: pd.DataFrame, target: str, task_choice: str, model_dir: Path) -> dict:
    if target not in df_raw.columns:
        raise ValueError('Please select a valid target column.')
    original_rows, original_cols = df_raw.shape
    duplicate_count = int(df_raw.duplicated().sum())
    df = df_raw.drop_duplicates().copy()
    empty_cols = [c for c in df.columns if df[c].isna().all()]
    df = df.drop(columns=empty_cols)
    if target in empty_cols:
        raise ValueError('The selected target column contains no usable values.')

    missing_before = df.isna().sum().to_dict()
    missing_total = int(df.isna().sum().sum())
    df = df.dropna(subset=[target]).copy()
    if len(df) < 30:
        raise ValueError('At least 30 rows with a non-empty target are required to train a model. For the assignment, use 500 or more records.')

    if task_choice == 'auto':
        is_classification = (not pd.api.types.is_numeric_dtype(df[target])) or df[target].nunique() <= 20
    else:
        is_classification = task_choice == 'classification'
    task = 'classification' if is_classification else 'regression'
    if is_classification and df[target].nunique() < 2:
        raise ValueError('Classification needs at least two target classes.')
    if not is_classification:
        df[target] = pd.to_numeric(df[target], errors='coerce')
        df = df.dropna(subset=[target])
        if len(df) < 30:
            raise ValueError('The selected regression target must contain at least 30 numeric values.')

    candidate_features = [c for c in df.columns if c != target]
    excluded = [c for c in candidate_features if _is_identifier_column(c, df[c])]
    features = [c for c in candidate_features if c not in excluded]
    if not features:
        features = candidate_features
        excluded = []
    if not features:
        raise ValueError('No feature columns remain after selecting the target.')

    numeric_cols = [c for c in features if pd.api.types.is_numeric_dtype(df[c])]
    categorical_cols = [c for c in features if c not in numeric_cols]
    eda_df, outlier_counts = _cap_outliers(df, numeric_cols)

    # Drop columns with no usable values after filtering; sklearn then imputes all remaining gaps.
    usable_features = [c for c in features if not df[c].isna().all()]
    if not usable_features:
        raise ValueError('No usable feature columns were found.')
    features = usable_features
    numeric_cols = [c for c in features if pd.api.types.is_numeric_dtype(df[c])]
    categorical_cols = [c for c in features if c not in numeric_cols]

    X = df[features].copy()
    y = df[target].copy()
    if is_classification:
        y = y.astype(str)
    transformers = []
    if numeric_cols:
        numeric_pipe = Pipeline([
            ('iqr_capper', IQRCapper()),
            ('imputer', SimpleImputer(strategy='median', keep_empty_features=True)),
            ('scaler', StandardScaler()),
        ])
        transformers.append(('numeric', numeric_pipe, numeric_cols))
    if categorical_cols:
        categorical_pipe = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent', keep_empty_features=True)),
            ('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=False, max_categories=40)),
        ])
        transformers.append(('categorical', categorical_pipe, categorical_cols))
    preprocessor = ColumnTransformer(transformers, remainder='drop', verbose_feature_names_out=False)
    estimator = RandomForestClassifier(n_estimators=180, random_state=42, class_weight='balanced_subsample', n_jobs=-1) if is_classification else RandomForestRegressor(n_estimators=180, random_state=42, n_jobs=-1)
    pipeline = Pipeline([('preprocessor', preprocessor), ('model', estimator)])

    stratify = y if is_classification and y.value_counts().min() >= 2 else None
    try:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=stratify)
    except ValueError:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    if len(X_train) < 2 or len(X_test) < 1:
        raise ValueError('Not enough rows for a train/test split.')
    pipeline.fit(X_train, y_train)
    predicted = pipeline.predict(X_test)

    if is_classification:
        metrics = {
            'accuracy': round(float(accuracy_score(y_test, predicted)), 4),
            'precision': round(float(precision_score(y_test, predicted, average='weighted', zero_division=0)), 4),
            'recall': round(float(recall_score(y_test, predicted, average='weighted', zero_division=0)), 4),
            'f1': round(float(f1_score(y_test, predicted, average='weighted', zero_division=0)), 4),
            'test_rows': int(len(y_test)),
            'train_rows': int(len(y_train)),
            'class_count': int(y.nunique()),
        }
        class_labels = [str(x) for x in pipeline.named_steps['model'].classes_]
        cm = confusion_matrix(y_test, predicted, labels=class_labels)
        fig, ax = plt.subplots(figsize=(5.6, 3.9))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_labels, yticklabels=class_labels, ax=ax)
        ax.set_title('Confusion matrix', loc='left', fontweight='bold')
        ax.set_xlabel('Predicted'); ax.set_ylabel('Actual')
        metric_plot = {'title': 'Confusion matrix', 'subtitle': 'Held-out test set', 'image': _fig_to_base64(fig)}
    else:
        rmse = float(np.sqrt(mean_squared_error(y_test, predicted)))
        metrics = {
            'mae': round(float(mean_absolute_error(y_test, predicted)), 4),
            'rmse': round(rmse, 4),
            'r2': round(float(r2_score(y_test, predicted)), 4) if len(y_test) > 1 else None,
            'test_rows': int(len(y_test)),
            'train_rows': int(len(y_train)),
        }
        fig, ax = plt.subplots(figsize=(5.6, 3.9))
        ax.scatter(y_test, predicted, alpha=.65, color='#4361ee')
        low = min(float(np.min(y_test)), float(np.min(predicted)))
        high = max(float(np.max(y_test)), float(np.max(predicted)))
        ax.plot([low, high], [low, high], linestyle='--', color='#ef8354')
        ax.set_title('Actual vs predicted', loc='left', fontweight='bold')
        ax.set_xlabel('Actual'); ax.set_ylabel('Predicted')
        metric_plot = {'title': 'Actual vs predicted', 'subtitle': 'Held-out test set', 'image': _fig_to_base64(fig)}

    # Refit using all eligible rows for the interactive prediction form.
    pipeline.fit(X, y)
    model_id = uuid.uuid4().hex
    model_dir.mkdir(parents=True, exist_ok=True)
    model_path = model_dir / f'{model_id}.joblib'
    dump({'pipeline': pipeline, 'features': features, 'target': target, 'task': task}, model_path)

    # Feature importance based on the fitted forest, aggregated to original input columns.
    try:
        transformed_names = pipeline.named_steps['preprocessor'].get_feature_names_out()
        importances = pipeline.named_steps['model'].feature_importances_
        ranked = sorted(zip([str(x) for x in transformed_names], importances), key=lambda x: x[1], reverse=True)[:12]
        importance = [{'feature': name, 'importance': round(float(score), 5)} for name, score in ranked]
    except Exception:
        importance = []

    plot_data = eda_df[features].copy()
    plot_data[target] = df[target].values
    eda_numeric = [c for c in plot_data.columns if pd.api.types.is_numeric_dtype(plot_data[c])]
    plots = _make_eda_plots(plot_data, target, eda_numeric)
    plots.append(metric_plot)

    # Build a readable, model-ready preview with feature gaps filled and IQR-capped numeric values.
    preview_df = eda_df.copy()
    for col in preview_df.columns:
        if col == target:
            continue
        if pd.api.types.is_numeric_dtype(preview_df[col]):
            fill_value = preview_df[col].median()
            if pd.notna(fill_value):
                preview_df[col] = preview_df[col].fillna(fill_value)
        else:
            modes = preview_df[col].dropna().mode()
            if not modes.empty:
                preview_df[col] = preview_df[col].fillna(modes.iloc[0])

    # Prediction-form metadata, including suggested values and categorical choices.
    input_fields = []
    for col in features:
        series = df[col]
        if pd.api.types.is_numeric_dtype(series):
            median = series.median()
            input_fields.append({'name': col, 'kind': 'number', 'value': '' if pd.isna(median) else str(round(float(median), 4)), 'choices': []})
        else:
            mode = series.dropna().mode()
            choices = [str(v) for v in series.dropna().astype(str).value_counts().head(12).index.tolist()]
            input_fields.append({'name': col, 'kind': 'text', 'value': str(mode.iloc[0]) if not mode.empty else '', 'choices': choices})

    missing_rows = [{'column': c, 'count': int(v)} for c, v in missing_before.items() if int(v) > 0]
    missing_rows.sort(key=lambda r: r['count'], reverse=True)
    cleaned_missing = int(plot_data[features].isna().sum().sum())
    result = {
        'model_id': model_id,
        'task': task,
        'target': target,
        'metrics': metrics,
        'plots': plots,
        'importance': importance,
        'input_fields': input_fields,
        'preview': [{str(k): _json_safe(v) for k, v in row.items()} for row in preview_df.head(8).to_dict(orient='records')],
        'columns': list(df.columns),
        'features': features,
        'summary': {
            'rows_original': int(original_rows),
            'rows_cleaned': int(len(df)),
            'columns_original': int(original_cols),
            'columns_cleaned': int(len(df.columns)),
            'duplicates_removed': duplicate_count,
            'empty_columns_removed': len(empty_cols),
            'target_missing_rows_removed': int(original_rows - duplicate_count - len(df)) if target in df.columns else 0,
            'missing_total_before': missing_total,
            'missing_total_after_imputation': int(preview_df.isna().sum().sum()),
            'outliers_capped': int(sum(outlier_counts.values())),
            'outlier_by_column': {k: v for k, v in outlier_counts.items() if v > 0},
            'excluded_columns': excluded,
            'missing_rows': missing_rows[:12],
            'warning_small_dataset': len(df) < 500,
        },
    }
    return result


def make_prediction(model_dir: Path, model_id: str, values: dict) -> dict:
    path = model_dir / f'{model_id}.joblib'
    if not path.exists():
        raise ValueError('The trained model is no longer available. Please run analysis again.')
    saved = load(path)
    features = saved['features']
    row = {}
    for col in features:
        raw = values.get(col, '')
        if raw == '' or raw is None:
            raise ValueError(f'Please enter a value for {col}.')
        row[col] = raw
    frame = pd.DataFrame([row], columns=features)
    # Infer feature types from the fitted preprocessing pipeline.
    for name, transformer, cols in saved['pipeline'].named_steps['preprocessor'].transformers_:
        if name == 'numeric':
            for col in cols:
                try:
                    frame[col] = pd.to_numeric(frame[col], errors='raise')
                except Exception:
                    raise ValueError(f'{col} must be a number.')
        else:
            for col in cols:
                frame[col] = frame[col].astype(str)
    model = saved['pipeline']
    prediction = model.predict(frame)[0]
    answer = str(prediction)
    probability = None
    if saved['task'] == 'classification' and hasattr(model, 'predict_proba'):
        probs = model.predict_proba(frame)[0]
        classes = model.named_steps['model'].classes_
        probability = round(float(np.max(probs)) * 100, 1)
        answer = str(prediction)
    return {'prediction': answer, 'confidence': probability, 'target': saved['target'], 'task': saved['task']}

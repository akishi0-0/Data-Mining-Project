import os
import sys
from pathlib import Path

# When frozen by PyInstaller, bundled templates live in sys._MEIPASS.
APP_ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
# Keep uploads, fitted models, sessions and logs outside the temporary EXE folder.
if os.name == 'nt':
    DATA_ROOT = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'DjangoAutoMLStudio'
else:
    DATA_ROOT = Path.home() / '.django_automl_studio'
DATA_ROOT.mkdir(parents=True, exist_ok=True)
(DATA_ROOT / 'uploads').mkdir(exist_ok=True)
(DATA_ROOT / 'models').mkdir(exist_ok=True)
(DATA_ROOT / 'matplotlib').mkdir(exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR', str(DATA_ROOT / 'matplotlib'))

SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'automl-studio-local-only-change-for-public-deployment')
DEBUG = False
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']
ROOT_URLCONF = 'automl_studio.urls'
WSGI_APPLICATION = 'automl_studio.wsgi.application'

INSTALLED_APPS = [
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'analyzer',
]
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]
TEMPLATES = [{
    'BACKEND': 'django.template.backends.django.DjangoTemplates',
    'DIRS': [APP_ROOT / 'templates'],
    'APP_DIRS': True,
    'OPTIONS': {'context_processors': [
        'django.template.context_processors.request',
        'django.contrib.messages.context_processors.messages',
    ]},
}]

DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3', 'NAME': DATA_ROOT / 'studio.sqlite3'}}
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True
STATIC_URL = '/static/'
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
SESSION_ENGINE = 'django.contrib.sessions.backends.db'
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = True
FILE_UPLOAD_MAX_MEMORY_SIZE = 25 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 25 * 1024 * 1024
X_FRAME_OPTIONS = 'DENY'

# Local machine only. Do not expose the built-in server to a public network.
APP_DATA_ROOT = DATA_ROOT

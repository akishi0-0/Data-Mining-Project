from django.urls import path
from analyzer import views

urlpatterns = [
    path('', views.home, name='home'),
    path('upload/', views.upload_dataset, name='upload'),
    path('analyze/', views.analyze_dataset, name='analyze'),
    path('predict/', views.predict, name='predict'),
    path('reset/', views.reset, name='reset'),
]
